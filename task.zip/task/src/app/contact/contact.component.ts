import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  contact: FormGroup;

  constructor() { }

  ngOnInit(): void {

    this.contact=new FormGroup({
      firstname:new FormControl('',Validators.required),
      lastname:new FormControl('',Validators.required),
      email:new FormControl('',[Validators.required,Validators.email]),
      officenumber:new FormControl('',[Validators.maxLength(10),Validators.minLength(10)]),
      mobilenumber:new FormControl('',[Validators.maxLength(10),Validators.minLength(10)]),
      org_name:new FormControl('',Validators.required),
      org_type:new FormControl('',Validators.required),
      Address:new FormControl('',)      

    })
  }

  onSubmit(){
    console.log(this.contact);
    console.warn(this.contact.value);


    
  }

}
